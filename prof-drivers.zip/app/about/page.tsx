"use client"

import { motion } from "framer-motion"
import { Users, Award, Clock, Shield, ChevronRight, Star } from "lucide-react"
import Link from "next/link"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900 text-white pt-20">
      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        <div className="absolute inset-0 z-0 opacity-20">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            {[...Array(20)].map((_, i) => (
              <motion.path
                key={i}
                d={`M${Math.random() * 100} ${Math.random() * 100} Q ${Math.random() * 100} ${Math.random() * 100}, ${Math.random() * 100} ${Math.random() * 100}`}
                stroke="currentColor"
                strokeWidth="0.5"
                fill="none"
                initial={{ pathLength: 0, opacity: 0.1 }}
                animate={{
                  pathLength: 1,
                  opacity: [0.1, 0.2, 0.1],
                  transition: {
                    duration: 5 + Math.random() * 5,
                    repeat: Number.POSITIVE_INFINITY,
                    repeatType: "reverse",
                  },
                }}
              />
            ))}
          </svg>
        </div>

        <div className="relative z-10 max-w-5xl mx-auto text-center">
          <motion.h1
            className="text-5xl md:text-6xl font-bold mb-4"
            initial={{ y: -50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            About Us
          </motion.h1>
          <motion.p
            className="text-xl text-slate-300 max-w-3xl mx-auto"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Professional drivers committed to safety, reliability, and exceptional service
          </motion.p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <div className="space-y-4 text-slate-300">
                <p>
                  Founded in 2015, Prof Drivers began with a simple mission: to provide safe, reliable transportation
                  services with a focus on professionalism and customer satisfaction.
                </p>
                <p>
                  What started as a small team of three drivers has grown into a network of over 50 professional drivers
                  serving multiple cities. Our growth is built on our commitment to excellence and our passion for
                  ensuring our clients arrive safely and on time.
                </p>
                <p>
                  Today, we're proud to be one of the leading professional driver services, trusted by individuals and
                  corporations alike for all their transportation needs.
                </p>
              </div>
            </motion.div>

            <motion.div
              className="relative h-80 lg:h-full min-h-[400px] rounded-xl overflow-hidden"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 to-slate-900/80 rounded-xl overflow-hidden">
                <motion.div
                  className="absolute inset-0 opacity-30"
                  animate={{
                    backgroundPosition: ["0% 0%", "100% 100%"],
                  }}
                  transition={{ duration: 20, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse" }}
                  style={{
                    backgroundImage:
                      "url(\"data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z' fill='%23ffffff' fillOpacity='0.1' fillRule='evenodd'/%3E%3C/svg%3E\")",
                    backgroundSize: "300px 300px",
                  }}
                />

                <div className="absolute inset-0 flex items-center justify-center">
                  <motion.div
                    className="w-32 h-32 rounded-full bg-blue-600/20 backdrop-blur-sm flex items-center justify-center"
                    animate={{
                      scale: [1, 1.05, 1],
                      boxShadow: [
                        "0 0 0 0 rgba(59, 130, 246, 0)",
                        "0 0 0 20px rgba(59, 130, 246, 0.3)",
                        "0 0 0 0 rgba(59, 130, 246, 0)",
                      ],
                    }}
                    transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
                  >
                    <span className="text-4xl font-bold">2015</span>
                  </motion.div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-slate-900/50">
        <div className="max-w-7xl mx-auto">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Our Core Values</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              The principles that guide everything we do at Prof Drivers
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <ValueCard
              icon={<Shield className="w-8 h-8" />}
              title="Safety First"
              description="We prioritize the safety of our clients above all else, with rigorous training and vehicle maintenance."
              delay={0}
            />

            <ValueCard
              icon={<Clock className="w-8 h-8" />}
              title="Punctuality"
              description="We understand the importance of time and ensure our drivers are always punctual and reliable."
              delay={0.1}
            />

            <ValueCard
              icon={<Award className="w-8 h-8" />}
              title="Excellence"
              description="We strive for excellence in every aspect of our service, from driver selection to customer support."
              delay={0.2}
            />

            <ValueCard
              icon={<Users className="w-8 h-8" />}
              title="Customer Focus"
              description="We tailor our services to meet the unique needs of each client, ensuring complete satisfaction."
              delay={0.3}
            />
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Our Leadership Team</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">Meet the experienced professionals behind Prof Drivers</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <TeamMember
              name="Rajesh Kumar"
              position="Founder & CEO"
              description="With over 15 years of experience in the transportation industry, Rajesh founded Prof Drivers with a vision to revolutionize professional driving services."
              delay={0}
            />

            <TeamMember
              name="Priya Sharma"
              position="Operations Director"
              description="Priya oversees all operational aspects of Prof Drivers, ensuring smooth coordination between drivers and clients for a seamless experience."
              delay={0.1}
            />

            <TeamMember
              name="Vikram Singh"
              position="Head of Driver Training"
              description="Vikram leads our comprehensive driver training program, maintaining our high standards of professionalism and safety."
              delay={0.2}
            />
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-slate-900/50">
        <div className="max-w-7xl mx-auto">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">What Our Clients Say</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              Testimonials from individuals and businesses who trust Prof Drivers
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <TestimonialCard
              quote="Prof Drivers has been our go-to service for all corporate events. Their professionalism and punctuality are unmatched."
              author="Ananya Patel"
              company="TechCorp India"
              rating={5}
              delay={0}
            />

            <TestimonialCard
              quote="I've been using their airport transfer service for two years now. Never once have they been late, and the drivers are always courteous."
              author="Rahul Mehta"
              company="Frequent Traveler"
              rating={5}
              delay={0.1}
            />

            <TestimonialCard
              quote="We hired Prof Drivers for our wedding day transportation. They made sure everything went smoothly and our guests were impressed."
              author="Neha & Arjun"
              company="Satisfied Couple"
              rating={5}
              delay={0.2}
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <motion.div
            className="bg-gradient-to-r from-blue-600/20 to-slate-800/50 backdrop-blur-sm p-8 md:p-12 rounded-2xl border border-slate-700 shadow-xl text-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl font-bold text-white mb-4">Ready to Experience Our Service?</h2>
            <p className="text-slate-300 max-w-2xl mx-auto mb-8">
              Join thousands of satisfied customers who trust Prof Drivers for their transportation needs.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-3 bg-blue-600 text-white font-medium rounded-lg shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2"
              >
                <Link href="/contact" className="flex items-center gap-2">
                  Contact Us <ChevronRight className="w-4 h-4" />
                </Link>
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-3 bg-slate-700 text-white font-medium rounded-lg border border-slate-600 flex items-center justify-center gap-2"
              >
                <Link href="/services" className="flex items-center gap-2">
                  Our Services <ChevronRight className="w-4 h-4" />
                </Link>
              </motion.button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  )
}

function ValueCard({ icon, title, description, delay }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ y: -5 }}
      className="bg-slate-800/50 backdrop-blur-sm rounded-xl overflow-hidden border border-slate-700 p-6"
    >
      <motion.div
        className="w-16 h-16 rounded-full bg-blue-600/20 flex items-center justify-center mb-6"
        whileHover={{ scale: 1.1, rotate: 5 }}
      >
        {icon}
      </motion.div>

      <h3 className="text-xl font-bold text-white mb-3">{title}</h3>
      <p className="text-slate-400">{description}</p>
    </motion.div>
  )
}

function TeamMember({ name, position, description, delay }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ y: -5 }}
      className="bg-slate-800/50 backdrop-blur-sm rounded-xl overflow-hidden border border-slate-700"
    >
      <div className="h-48 bg-gradient-to-br from-blue-600/30 to-slate-800 flex items-center justify-center">
        <motion.div
          className="w-24 h-24 rounded-full bg-slate-700 flex items-center justify-center text-3xl font-bold"
          whileHover={{ scale: 1.1 }}
        >
          {name
            .split(" ")
            .map((n) => n[0])
            .join("")}
        </motion.div>
      </div>
      <div className="p-6">
        <h3 className="text-xl font-bold text-white mb-1">{name}</h3>
        <p className="text-blue-400 mb-4">{position}</p>
        <p className="text-slate-400">{description}</p>
      </div>
    </motion.div>
  )
}

function TestimonialCard({ quote, author, company, rating, delay }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ y: -5 }}
      className="bg-slate-800/50 backdrop-blur-sm rounded-xl overflow-hidden border border-slate-700 p-6"
    >
      <div className="flex mb-4">
        {[...Array(rating)].map((_, i) => (
          <Star key={i} className="w-5 h-5 text-yellow-500 fill-yellow-500" />
        ))}
      </div>
      <p className="text-slate-300 mb-6 italic">"{quote}"</p>
      <div>
        <p className="font-semibold text-white">{author}</p>
        <p className="text-slate-400 text-sm">{company}</p>
      </div>
    </motion.div>
  )
}
