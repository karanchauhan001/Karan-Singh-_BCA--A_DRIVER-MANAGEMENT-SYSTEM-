"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Phone, Mail, MapPin, Send, MessageSquare, Clock, CheckCircle } from "lucide-react"

export default function ContactPage() {
  const [formStatus, setFormStatus] = useState("idle") // idle, submitting, success, error
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  })

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    setFormStatus("submitting")

    // Simulate form submission
    setTimeout(() => {
      setFormStatus("success")
      // Reset form after 3 seconds
      setTimeout(() => {
        setFormStatus("idle")
        setFormData({
          name: "",
          email: "",
          phone: "",
          subject: "",
          message: "",
        })
      }, 3000)
    }, 1500)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900 text-white pt-20">
      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        <div className="absolute inset-0 z-0 opacity-20">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            {[...Array(20)].map((_, i) => (
              <motion.path
                key={i}
                d={`M${Math.random() * 100} ${Math.random() * 100} Q ${Math.random() * 100} ${Math.random() * 100}, ${Math.random() * 100} ${Math.random() * 100}`}
                stroke="currentColor"
                strokeWidth="0.5"
                fill="none"
                initial={{ pathLength: 0, opacity: 0.1 }}
                animate={{
                  pathLength: 1,
                  opacity: [0.1, 0.2, 0.1],
                  transition: {
                    duration: 5 + Math.random() * 5,
                    repeat: Number.POSITIVE_INFINITY,
                    repeatType: "reverse",
                  },
                }}
              />
            ))}
          </svg>
        </div>

        <div className="relative z-10 max-w-5xl mx-auto text-center">
          <motion.h1
            className="text-5xl md:text-6xl font-bold mb-4"
            initial={{ y: -50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            Contact Us
          </motion.h1>
          <motion.p
            className="text-xl text-slate-300 max-w-3xl mx-auto"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Have questions or need to book a ride? We're here to help.
          </motion.p>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <ContactCard
              icon={<Phone className="w-6 h-6" />}
              title="Phone"
              details={["+91 9876543210", "+91 9876543211"]}
              delay={0}
            />

            <ContactCard
              icon={<Mail className="w-6 h-6" />}
              title="Email"
              details={["info@profdrivers.com", "support@profdrivers.com"]}
              delay={0.1}
            />

            <ContactCard
              icon={<MapPin className="w-6 h-6" />}
              title="Address"
              details={["123 Driving Street", "Mumbai, Maharashtra 400001"]}
              delay={0.2}
            />
          </div>
        </div>
      </section>

      {/* Contact Form and Map */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="bg-slate-800/50 backdrop-blur-sm rounded-xl border border-slate-700 p-6 md:p-8"
            >
              <h2 className="text-2xl font-bold mb-6 flex items-center">
                <MessageSquare className="w-6 h-6 mr-2 text-blue-400" />
                Send Us a Message
              </h2>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-slate-300 mb-2">
                      Full Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                      disabled={formStatus !== "idle"}
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-slate-300 mb-2">
                      Email Address
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                      disabled={formStatus !== "idle"}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-slate-300 mb-2">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                      disabled={formStatus !== "idle"}
                    />
                  </div>

                  <div>
                    <label htmlFor="subject" className="block text-sm font-medium text-slate-300 mb-2">
                      Subject
                    </label>
                    <input
                      type="text"
                      id="subject"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                      disabled={formStatus !== "idle"}
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-slate-300 mb-2">
                    Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={5}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                    disabled={formStatus !== "idle"}
                  ></textarea>
                </div>

                <motion.button
                  type="submit"
                  className="px-6 py-3 bg-blue-600 text-white font-medium rounded-lg shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 w-full md:w-auto"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  disabled={formStatus !== "idle"}
                >
                  {formStatus === "idle" && (
                    <>
                      Send Message <Send className="w-4 h-4" />
                    </>
                  )}
                  {formStatus === "submitting" && (
                    <>
                      <svg
                        className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        ></circle>
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        ></path>
                      </svg>
                      Sending...
                    </>
                  )}
                  {formStatus === "success" && (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" /> Message Sent
                    </>
                  )}
                </motion.button>
              </form>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="bg-slate-800/50 backdrop-blur-sm rounded-xl border border-slate-700 overflow-hidden"
            >
              <div className="p-6 md:p-8">
                <h2 className="text-2xl font-bold mb-6 flex items-center">
                  <MapPin className="w-6 h-6 mr-2 text-blue-400" />
                  Our Location
                </h2>
              </div>

              {/* Interactive Map Placeholder */}
              <div className="relative h-[400px] bg-slate-700 overflow-hidden">
                <div className="absolute inset-0 bg-slate-800">
                  {/* Animated Map Elements */}
                  <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                    {/* Grid Lines */}
                    {[...Array(10)].map((_, i) => (
                      <motion.line
                        key={`h-${i}`}
                        x1="0"
                        y1={i * 10}
                        x2="100"
                        y2={i * 10}
                        stroke="rgba(100, 116, 139, 0.2)"
                        strokeWidth="0.2"
                        initial={{ pathLength: 0 }}
                        animate={{ pathLength: 1 }}
                        transition={{ duration: 2, delay: i * 0.1 }}
                      />
                    ))}
                    {[...Array(10)].map((_, i) => (
                      <motion.line
                        key={`v-${i}`}
                        x1={i * 10}
                        y1="0"
                        x2={i * 10}
                        y2="100"
                        stroke="rgba(100, 116, 139, 0.2)"
                        strokeWidth="0.2"
                        initial={{ pathLength: 0 }}
                        animate={{ pathLength: 1 }}
                        transition={{ duration: 2, delay: i * 0.1 }}
                      />
                    ))}

                    {/* Roads */}
                    <motion.path
                      d="M0 50 H100"
                      stroke="rgba(100, 116, 139, 0.5)"
                      strokeWidth="1"
                      fill="none"
                      initial={{ pathLength: 0 }}
                      animate={{ pathLength: 1 }}
                      transition={{ duration: 3 }}
                    />
                    <motion.path
                      d="M50 0 V100"
                      stroke="rgba(100, 116, 139, 0.5)"
                      strokeWidth="1"
                      fill="none"
                      initial={{ pathLength: 0 }}
                      animate={{ pathLength: 1 }}
                      transition={{ duration: 3 }}
                    />

                    {/* Location Pin */}
                    <motion.circle
                      cx="50"
                      cy="50"
                      r="3"
                      fill="#3b82f6"
                      initial={{ scale: 0 }}
                      animate={{ scale: [0, 1.2, 1] }}
                      transition={{ duration: 1, delay: 3 }}
                    />
                    <motion.circle
                      cx="50"
                      cy="50"
                      r="10"
                      fill="none"
                      stroke="#3b82f6"
                      strokeWidth="0.5"
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{
                        scale: [0, 1.5, 1],
                        opacity: [0, 0.8, 0],
                      }}
                      transition={{
                        duration: 2,
                        repeat: Number.POSITIVE_INFINITY,
                        repeatDelay: 1,
                      }}
                    />
                  </svg>

                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <motion.div
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 3.5 }}
                      >
                        <MapPin className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                        <p className="font-bold text-white">Prof Drivers HQ</p>
                        <p className="text-slate-300">123 Driving Street, Mumbai</p>
                      </motion.div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Business Hours */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <motion.div
            className="bg-slate-800/50 backdrop-blur-sm rounded-xl border border-slate-700 p-6 md:p-8"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <Clock className="w-6 h-6 mr-2 text-blue-400" />
              Business Hours
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Office Hours</h3>
                <ul className="space-y-3">
                  <BusinessHour day="Monday - Friday" hours="9:00 AM - 6:00 PM" />
                  <BusinessHour day="Saturday" hours="10:00 AM - 4:00 PM" />
                  <BusinessHour day="Sunday" hours="Closed" />
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-4">Driver Services</h3>
                <ul className="space-y-3">
                  <BusinessHour day="Monday - Friday" hours="24 Hours" />
                  <BusinessHour day="Saturday" hours="24 Hours" />
                  <BusinessHour day="Sunday" hours="24 Hours" />
                  <li className="text-slate-400 text-sm italic">* Booking in advance is recommended</li>
                </ul>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-slate-400">Find quick answers to common questions about our services</p>
          </motion.div>

          <div className="space-y-6">
            <FAQ
              question="How far in advance should I book a driver?"
              answer="We recommend booking at least 24 hours in advance for standard services. For special events or peak times, booking 3-5 days ahead is advisable. However, we do accommodate last-minute requests based on driver availability."
              delay={0}
            />

            <FAQ
              question="What payment methods do you accept?"
              answer="We accept all major credit cards, UPI payments, net banking, and cash. For corporate clients, we also offer monthly invoicing options."
              delay={0.1}
            />

            <FAQ
              question="Can I request a specific driver?"
              answer="Yes, you can request a specific driver when making your booking. If that driver is available, we'll be happy to assign them to your service."
              delay={0.2}
            />

            <FAQ
              question="What happens if my flight is delayed?"
              answer="For airport transfers, we monitor flight arrivals in real-time. Your driver will adjust their schedule according to your actual arrival time at no extra charge."
              delay={0.3}
            />
          </div>
        </div>
      </section>
    </div>
  )
}

function ContactCard({ icon, title, details, delay }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ y: -5 }}
      className="bg-slate-800/50 backdrop-blur-sm rounded-xl overflow-hidden border border-slate-700 p-6 text-center"
    >
      <motion.div
        className="w-16 h-16 rounded-full bg-blue-600/20 flex items-center justify-center mx-auto mb-6"
        whileHover={{ scale: 1.1, rotate: 5 }}
      >
        {icon}
      </motion.div>

      <h3 className="text-xl font-bold text-white mb-4">{title}</h3>
      <ul className="space-y-2">
        {details.map((detail, index) => (
          <li key={index} className="text-slate-300">
            {detail}
          </li>
        ))}
      </ul>
    </motion.div>
  )
}

function BusinessHour({ day, hours }) {
  return (
    <li className="flex justify-between">
      <span className="text-slate-300">{day}</span>
      <span className="font-medium text-white">{hours}</span>
    </li>
  )
}

function FAQ({ question, answer, delay }) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      className="bg-slate-800/50 backdrop-blur-sm rounded-xl overflow-hidden border border-slate-700"
    >
      <button onClick={() => setIsOpen(!isOpen)} className="w-full p-6 text-left flex justify-between items-center">
        <h3 className="text-lg font-medium text-white">{question}</h3>
        <motion.div animate={{ rotate: isOpen ? 45 : 0 }} transition={{ duration: 0.3 }}>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-5 w-5 text-slate-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
        </motion.div>
      </button>

      <motion.div
        initial={false}
        animate={{
          height: isOpen ? "auto" : 0,
          opacity: isOpen ? 1 : 0,
        }}
        transition={{ duration: 0.3 }}
        className="overflow-hidden"
      >
        <div className="p-6 pt-0 text-slate-300 border-t border-slate-700">{answer}</div>
      </motion.div>
    </motion.div>
  )
}
