"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Car, Plane, Building, Heart, ChevronRight, Calendar, MapPin, Clock } from "lucide-react"
import Link from "next/link"
import BookingModal from "@/components/booking-modal"

export default function HomePage() {
  const [isBookingOpen, setIsBookingOpen] = useState(false)
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <>
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 bg-slate-950 z-0">
          <div className="absolute inset-0 opacity-30">
            <motion.div
              className="absolute inset-0"
              style={{
                background: "radial-gradient(circle at center, rgba(59, 130, 246, 0.3) 0%, rgba(0, 0, 0, 0) 70%)",
              }}
              animate={{
                scale: [1, 1.1, 1],
                opacity: [0.3, 0.4, 0.3],
              }}
              transition={{
                duration: 8,
                repeat: Number.POSITIVE_INFINITY,
                repeatType: "reverse",
              }}
            />
          </div>

          {/* Animated Lines */}
          <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
            {[...Array(10)].map((_, i) => (
              <motion.path
                key={i}
                d={`M0 ${100 + i * 50} Q ${250 + Math.random() * 100} ${150 + i * 50}, ${500 + Math.random() * 100} ${100 + i * 50} T 1000 ${100 + i * 50}`}
                stroke="rgba(59, 130, 246, 0.2)"
                strokeWidth="1"
                fill="none"
                initial={{ pathLength: 0, opacity: 0 }}
                animate={{
                  pathLength: 1,
                  opacity: 0.2,
                  transition: {
                    duration: 5 + i * 0.5,
                    ease: "easeInOut",
                    repeat: Number.POSITIVE_INFINITY,
                    repeatType: "loop",
                    repeatDelay: 1,
                  },
                }}
              />
            ))}
          </svg>
        </div>

        {/* Content */}
        <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <motion.h1
              className="text-4xl md:text-6xl font-bold text-white mb-6"
              animate={{
                textShadow: [
                  "0 0 8px rgba(59, 130, 246, 0)",
                  "0 0 16px rgba(59, 130, 246, 0.5)",
                  "0 0 8px rgba(59, 130, 246, 0)",
                ],
              }}
              transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
            >
              Professional Drivers
              <br />
              <span className="text-blue-400">At Your Service</span>
            </motion.h1>

            <motion.p
              className="text-xl text-slate-300 mb-8 max-w-2xl mx-auto"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.8 }}
            >
              Get a reliable, professional driver for any occasion. Experience safe, punctual, and comfortable
              transportation.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.8 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-3 bg-blue-600 text-white font-medium rounded-lg shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2"
                onClick={() => setIsBookingOpen(true)}
              >
                <Calendar className="w-5 h-5" />
                Book Your Ride
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-3 bg-slate-800 text-white font-medium rounded-lg border border-slate-700 flex items-center justify-center gap-2"
              >
                <Link href="/services" className="flex items-center gap-2">
                  Explore Services <ChevronRight className="w-4 h-4" />
                </Link>
              </motion.button>
            </motion.div>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10"
          animate={{
            y: [0, 10, 0],
            opacity: [0.6, 1, 0.6],
          }}
          transition={{
            duration: 2,
            repeat: Number.POSITIVE_INFINITY,
          }}
        >
          <div className="w-8 h-12 rounded-full border-2 border-slate-400 flex items-start justify-center p-1">
            <motion.div
              className="w-1 h-3 bg-blue-400 rounded-full"
              animate={{
                y: [0, 6, 0],
              }}
              transition={{
                duration: 2,
                repeat: Number.POSITIVE_INFINITY,
              }}
            />
          </div>
        </motion.div>
      </section>

      {/* Services Preview */}
      <section className="py-20 bg-gradient-to-b from-slate-950 to-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Vehicle Driving Solutions</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">Professional drivers for all your transportation needs</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <ServiceCard
              icon={<Car />}
              number="1"
              title="Designated Drivers"
              description="Avoid DUIs and get home safe after a night out. Starting at 300₹ only."
              color="from-blue-600 to-blue-400"
              delay={0}
            />

            <ServiceCard
              icon={<Plane />}
              number="2"
              title="Airport Transfers"
              description="Stress-free airport transportation with tracked arrival times. Flat rate of $60."
              color="from-purple-600 to-purple-400"
              delay={0.1}
            />

            <ServiceCard
              icon={<Building />}
              number="3"
              title="Corporate Events"
              description="Professional chauffeur services for corporate events and business functions."
              color="from-emerald-600 to-emerald-400"
              delay={0.2}
            />

            <ServiceCard
              icon={<Heart />}
              number="4"
              title="Wedding Transportation"
              description="Elegant and reliable transportation for your special day."
              color="from-rose-600 to-rose-400"
              delay={0.3}
            />
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">How It Works</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">Book your professional driver in three simple steps</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <StepCard
              icon={<Calendar className="w-8 h-8" />}
              title="Book Online"
              description="Schedule your ride through our easy-to-use booking system."
              step={1}
              delay={0}
            />

            <StepCard
              icon={<MapPin className="w-8 h-8" />}
              title="Get Picked Up"
              description="Your professional driver will arrive at your location on time."
              step={2}
              delay={0.2}
            />

            <StepCard
              icon={<Clock className="w-8 h-8" />}
              title="Enjoy Your Ride"
              description="Relax and enjoy a safe, comfortable journey to your destination."
              step={3}
              delay={0.4}
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-b from-slate-900 to-slate-950 relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <svg className="w-full h-full opacity-20" viewBox="0 0 100 100" preserveAspectRatio="none">
            {[...Array(10)].map((_, i) => (
              <motion.circle
                key={i}
                cx={50 + Math.random() * 40 - 20}
                cy={50 + Math.random() * 40 - 20}
                r={5 + Math.random() * 20}
                fill="none"
                stroke="currentColor"
                strokeWidth="0.5"
                initial={{ opacity: 0.1, scale: 0 }}
                animate={{
                  opacity: [0.1, 0.3, 0.1],
                  scale: [0, 1, 0],
                  transition: {
                    duration: 10 + Math.random() * 10,
                    repeat: Number.POSITIVE_INFINITY,
                    repeatType: "loop",
                  },
                }}
              />
            ))}
          </svg>
        </div>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            className="bg-slate-800/50 backdrop-blur-lg p-8 md:p-12 rounded-2xl border border-slate-700 shadow-xl"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-white mb-4">Ready to Book Your Ride?</h2>
              <p className="text-slate-300 max-w-2xl mx-auto">
                Experience the convenience and safety of professional driving services.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-3 bg-blue-600 text-white font-medium rounded-lg shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2"
                onClick={() => setIsBookingOpen(true)}
              >
                <Calendar className="w-5 h-5" />
                Book Now
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-3 bg-slate-700 text-white font-medium rounded-lg border border-slate-600 flex items-center justify-center gap-2"
              >
                <Link href="/contact" className="flex items-center gap-2">
                  Contact Us
                </Link>
              </motion.button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Booking Modal */}
      <AnimatePresence>{isBookingOpen && <BookingModal onClose={() => setIsBookingOpen(false)} />}</AnimatePresence>
    </>
  )
}

function ServiceCard({ icon, number, title, description, color, delay }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ y: -5 }}
      className="relative rounded-xl overflow-hidden"
    >
      <div className="bg-slate-800 rounded-xl overflow-hidden border border-slate-700 h-full">
        <div className={`h-2 bg-gradient-to-r ${color}`} />
        <div className="p-6">
          <div className="flex items-start gap-4 mb-4">
            <div
              className={`flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-br ${color} text-white font-bold`}
            >
              {number}
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-bold text-white mb-1">{title}</h3>
              <p className="text-slate-400">{description}</p>
            </div>
          </div>

          <motion.div whileHover={{ x: 5 }} className="mt-4">
            <Link
              href={`/services#${title.toLowerCase().replace(/\s+/g, "-")}`}
              className="inline-flex items-center text-blue-400 hover:text-blue-300 transition-colors"
            >
              Learn More <ChevronRight className="w-4 h-4 ml-1" />
            </Link>
          </motion.div>
        </div>
      </div>
    </motion.div>
  )
}

function StepCard({ icon, title, description, step, delay }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      className="relative"
    >
      <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl overflow-hidden border border-slate-700 p-6 h-full">
        <motion.div
          className="w-16 h-16 rounded-full bg-blue-600/20 flex items-center justify-center mb-6 mx-auto"
          whileHover={{ scale: 1.1, rotate: 5 }}
        >
          {icon}
        </motion.div>

        <h3 className="text-xl font-bold text-white mb-3 text-center">
          Step {step}: {title}
        </h3>
        <p className="text-slate-400 text-center">{description}</p>
      </div>
    </motion.div>
  )
}
