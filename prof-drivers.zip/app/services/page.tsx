"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Car, Plane, Building, Heart } from "lucide-react"
import Link from "next/link"

export default function ServicesPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900 text-white">
      {/* Hero Section */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden"
      >
        <div className="absolute inset-0 z-0 opacity-20">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            {[...Array(20)].map((_, i) => (
              <motion.path
                key={i}
                d={`M${Math.random() * 100} ${Math.random() * 100} Q ${Math.random() * 100} ${Math.random() * 100}, ${Math.random() * 100} ${Math.random() * 100}`}
                stroke="currentColor"
                strokeWidth="0.5"
                fill="none"
                initial={{ pathLength: 0, opacity: 0.1 }}
                animate={{
                  pathLength: 1,
                  opacity: [0.1, 0.2, 0.1],
                  transition: {
                    duration: 5 + Math.random() * 5,
                    repeat: Number.POSITIVE_INFINITY,
                    repeatType: "reverse",
                  },
                }}
              />
            ))}
          </svg>
        </div>

        <div className="relative z-10 max-w-5xl mx-auto text-center">
          <motion.h1
            className="text-5xl md:text-6xl font-bold mb-4"
            initial={{ y: -50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            Our Services
          </motion.h1>
          <motion.p
            className="text-xl text-slate-300 max-w-3xl mx-auto"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Professional driving solutions tailored to your specific needs
          </motion.p>
        </div>
      </motion.div>

      {/* Services Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <ServiceCard
            icon={<Car className="w-10 h-10" />}
            title="Designated Drivers"
            description="Safe rides after a night out"
            details="Avoid DUIs and get home safe after a night out. Our designated driver service ensures you and your vehicle get home safely. Starting at 300₹ only."
            color="from-blue-600 to-blue-400"
            delay={0}
          />

          <ServiceCard
            icon={<Plane className="w-10 h-10" />}
            title="Airport Transfers"
            description="Stress-free airport transportation"
            details="Stress-free rides to and from the airport with tracked arrival times. Never miss a flight again with our reliable airport transfer service. Flat rate of $60."
            color="from-purple-600 to-purple-400"
            delay={0.1}
          />

          <ServiceCard
            icon={<Building className="w-10 h-10" />}
            title="Corporate Events"
            description="Professional chauffeur services"
            details="Professional chauffeur services for corporate events. Impress your clients and ensure your team arrives on time and in style to important business functions."
            color="from-emerald-600 to-emerald-400"
            delay={0.2}
          />

          <ServiceCard
            icon={<Heart className="w-10 h-10" />}
            title="Wedding Transportation"
            description="Elegant rides for your special day"
            details="Elegant and reliable transportation for your special day. Our professional drivers ensure you and your wedding party arrive in style and on time."
            color="from-rose-600 to-rose-400"
            delay={0.3}
          />
        </div>
      </div>
    </div>
  )
}

function ServiceCard({ icon, title, description, details, color, delay }) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      className="relative rounded-xl overflow-hidden"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="bg-slate-800 rounded-xl overflow-hidden border border-slate-700 h-full">
        <div className={`h-32 bg-gradient-to-r ${color} flex items-center justify-center relative overflow-hidden`}>
          <motion.div
            className="absolute inset-0 opacity-30"
            animate={{
              backgroundPosition: isHovered ? ["0% 0%", "100% 100%"] : ["0% 0%", "0% 0%"],
            }}
            transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse" }}
            style={{
              backgroundImage:
                "url(\"data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z' fill='%23ffffff' fillOpacity='0.1' fillRule='evenodd'/%3E%3C/svg%3E\")",
              backgroundSize: "300px 300px",
            }}
          />

          <motion.div
            animate={{
              scale: isHovered ? 1.2 : 1,
              rotate: isHovered ? 10 : 0,
            }}
            transition={{ type: "spring", stiffness: 200, damping: 10 }}
            className="relative z-10 bg-slate-900/30 p-4 rounded-full"
          >
            {icon}
          </motion.div>
        </div>

        <div className="p-6">
          <h3 className="text-xl font-bold mb-2">{title}</h3>
          <p className="text-slate-400 mb-4">{description}</p>
          <p className="text-slate-300 mb-6">{details}</p>

          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Link
              href="#"
              className="inline-block bg-slate-700 hover:bg-slate-600 text-white font-medium py-2 px-6 rounded-lg transition-colors duration-200 text-center w-full"
            >
              Learn More
            </Link>
          </motion.div>
        </div>
      </div>
    </motion.div>
  )
}
